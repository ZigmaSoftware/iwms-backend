from rest_framework import serializers


class LoginSerializer(serializers.Serializer):
    username = serializers.CharField(required=False, allow_blank=True)
    email = serializers.EmailField(required=False, allow_blank=True)
    password = serializers.CharField(write_only=True, required=True)

    def validate(self, attrs):
        """Ensure that at least one identifier is present."""
        username = attrs.get("username", "") or ""
        email = attrs.get("email", "") or ""

        if not username.strip() and not email.strip():
            raise serializers.ValidationError(
                "Please provide either a username or an email."
            )

        attrs["username"] = username.strip()
        attrs["email"] = email.strip()
        return attrs

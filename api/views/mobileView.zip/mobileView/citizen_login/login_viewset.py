from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.contrib.auth.models import User
from rest_framework.authtoken.models import Token

from api.serializers.mobileView.citizenLogin.login_serializer import LoginSerializer

class CitizenLogin(APIView):

    def post(self, request):
        serializer = LoginSerializer(data=request.data)

        if not serializer.is_valid():
            return Response(
                {"status": False, "message": "Invalid payload", "errors": serializer.errors},
                status=status.HTTP_400_BAD_REQUEST
            )

        username = serializer.validated_data.get("username")
        email = serializer.validated_data.get("email")
        password = serializer.validated_data.get("password")

        # Always prefer email → then username
        user = None

        if email:
            user = User.objects.filter(email__iexact=email, is_active=True).first()

        if not user and username:
            user = User.objects.filter(username=username, is_active=True).first()

        # Validate user
        if not user or not user.check_password(password):
            return Response(
                {"status": False, "message": "Invalid credentials"},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Token generation
        token, _ = Token.objects.get_or_create(user=user)

        return Response({
            "status": True,
            "message": "Login successful",
            "token": token.key,
            "user": {
                "username": user.username,
                "email": user.email,
                "first_name": user.first_name,
                "last_name": user.last_name
            }
        }, status=status.HTTP_200_OK)
